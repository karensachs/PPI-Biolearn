java -Xmx1000M -classpath $1/biolearn.jar:$1/jung-1.7.6.jar:$1/commons-collections-3.2.jar:$1/colt.jar:$1/Jama-1.0.2.jar biolearn.Applications.LearnBayesianNetworkInteractively $2
